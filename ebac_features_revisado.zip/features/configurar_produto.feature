# language: pt
Funcionalidade: Configurar produto para adicionar ao carrinho

  História de usuário:
    Como cliente da EBAC-SHOP
    Quero configurar meu produto de acordo com meu tamanho e gosto e escolher a quantidade
    Para depois inserir no carrinho

  Contexto:
    Dado que o cliente está na página de detalhes de um produto da EBAC-SHOP

  Cenário: Adicionar produto com configurações obrigatórias preenchidas
    Quando o cliente selecionar cor, tamanho, quantidade válida e adicionar o produto ao carrinho
    Então o produto deve ser adicionado ao carrinho com as configurações selecionadas

  Cenário: Exibir alerta ao tentar adicionar produto sem configurações obrigatórias
    Quando o cliente tentar adicionar o produto ao carrinho sem informar cor, tamanho ou quantidade
    Então o sistema deve exibir uma mensagem informando que cor, tamanho e quantidade são obrigatórios

  Cenário: Limpar configurações do produto
    Quando o cliente selecionar cor, tamanho, quantidade e clicar no botão "limpar"
    Então as configurações do produto devem voltar ao estado original

  Esquema do Cenário: Validar quantidade permitida por venda
    Quando o cliente selecionar cor, tamanho, informar a quantidade <quantidade> e adicionar o produto ao carrinho
    Então o sistema deve apresentar o resultado "<resultado>"

    Exemplos:
      | quantidade | resultado                                    |
      | 1          | Produto adicionado ao carrinho               |
      | 10         | Produto adicionado ao carrinho               |
      | 11         | Quantidade máxima permitida é de 10 produtos |
      | 0          | Quantidade obrigatória inválida              |
