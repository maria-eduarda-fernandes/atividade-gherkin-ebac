# language: pt
Funcionalidade: Cadastro no checkout

  História de usuário:
    Como cliente da EBAC-SHOP
    Quero concluir meu cadastro
    Para finalizar minha compra

  Contexto:
    Dado que o cliente está na tela de cadastro do checkout

  Cenário: Cadastrar cliente com dados obrigatórios válidos
    Quando o cliente preencher todos os campos obrigatórios, informar e-mail válido e clicar no botão de cadastrar
    Então o cadastro deve ser concluído com sucesso

  Cenário: Exibir erro para e-mail com formato inválido
    Quando o cliente preencher todos os campos obrigatórios, informar e-mail inválido e clicar no botão de cadastrar
    Então o sistema deve exibir uma mensagem de erro para o campo e-mail

  Cenário: Exibir alerta para campos obrigatórios vazios
    Quando o cliente tentar cadastrar com um ou mais campos obrigatórios vazios
    Então o sistema deve exibir uma mensagem de alerta sobre campos obrigatórios não preenchidos

  Esquema do Cenário: Validar cadastro com combinações de dados
    Quando o cliente informar nome "<nome>", e-mail "<email>", endereço "<endereco>" e clicar no botão de cadastrar
    Então o sistema deve apresentar o resultado "<resultado>"

    Exemplos:
      | nome        | email             | endereco       | resultado                                                   |
      | Maria Silva | maria@ebac.com.br | Rua Teste, 100 | Cadastro concluído com sucesso                              |
      | Maria Silva | mariaebac.com.br  | Rua Teste, 100 | Mensagem de erro para e-mail inválido                       |
      |             | maria@ebac.com.br | Rua Teste, 100 | Mensagem de alerta para campos obrigatórios não preenchidos |
      | Maria Silva |                   | Rua Teste, 100 | Mensagem de alerta para campos obrigatórios não preenchidos |
      | Maria Silva | maria@ebac.com.br |                | Mensagem de alerta para campos obrigatórios não preenchidos |
