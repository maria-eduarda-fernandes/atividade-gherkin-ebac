# language: pt
Funcionalidade: Login na plataforma

  História de usuário:
    Como cliente da EBAC-SHOP
    Quero fazer o login na plataforma
    Para visualizar meus pedidos

  Contexto:
    Dado que o cliente está na tela de login da EBAC-SHOP

  Cenário: Realizar login com dados válidos
    Quando o cliente informar usuário válido, senha válida e clicar no botão de login
    Então o sistema deve direcionar o cliente para a tela de checkout

  Esquema do Cenário: Exibir alerta para login com dados inválidos
    Quando o cliente informar o usuário "<usuario>", a senha "<senha>" e clicar no botão de login
    Então o sistema deve exibir a mensagem de alerta "Usuário ou senha inválidos"

    Exemplos:
      | usuario            | senha       |
      | cliente@ebac.com.br | senhaerrada |
      | usuarioinvalido     | senha123    |
      |                    | senha123    |
      | cliente@ebac.com.br |             |
